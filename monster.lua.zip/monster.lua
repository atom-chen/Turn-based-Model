--怪物
local baseBio = require("bio.bio")
local monster = class("monster",baseBio)

function monster:ctor(x,y,id,id_,type)
	self.super.ctor(self,x,y,id,id_,type)
end

function monster:create(x,y,id,id_,type)
	return monster.new(x,y,id,id_,type)
end
--普通攻击 
function monster:attack(callback,isLoop)
	--获取攻击动画
	local fileName = self:getActionById()
	
end
--对敌方释放攻击性技能
function monster:skillToAttack(skillId,callback)
	releaseSkill(skillId,callback,display.cx,display.cy)
end

--对我方使用辅助性技能
function monster:skillToSelfPart(skillId,callback,x,y)
	releaseSkill(skillId,callback,x,y)
end



return monster